# Opening playtest

Target: roughly 8–12 minutes for an exploratory first visit. This is a target to measure, not a measured result. Automated traversal verifies reachability, not how long a human spends reading or whether the writing lands.

Start a new investigation. Read at a comfortable pace. Follow the boy's direction, examine what draws attention, and open the case file only when you want to. After meeting Odell, decide what to file and return to the gate. The completion screen records what you actually found.

Record:

1. Time to the garden, first observation, Odell, and departure.
2. Did the camera and movement feel like inhabiting Walter? Where did the camera obstruct a clue?
3. Did the ground lead you toward both scenes without a permanent objective marker?
4. Was the iris opening noticeable, distracting, or too ordinary?
5. Did the report choice feel like something Walter was doing? Did you understand what survived differently?
6. Which intertitles felt like dialogue, and which felt like narration interrupting play?
7. Was there a moment when evidence became satisfying to understand?
8. Did you want to continue into town?
9. At the kitchen wing yard: did anything about the groundskeeper's accent read as unusual before it was pointed out here? Did the refusal itself read as expertise, or as fear?
10. At Odell's dismissal: which response did you pick, and why? Did the other option feel like a real path not taken, or an obviously worse choice?
11. Did the barman's and Father Behan's menus feel like real conversations to return to, or like a checklist to clear? Did unlocking each next topic feel earned or arbitrary?
12. Did the woman outside Kessler's shop feel like a missed opportunity to ask more, or did her leaving before Walter could press her read as intentional? Did her warning connect to anything else on its own, before the board pointed it out?

Then try a minimal second run: go to Odell, prepare a report, and leave without opening the case file. Compare its record to the first run. Save midway, quit, and continue. Optional third check: return to the gardener wearing the plain coat.

Use the accessibility menu before play. Test enlarged text and zero distortion. The same observations and decisions must remain available and readable.

Next production decisions: camera feel, evidence inspection staging, Walter's initial characterization, civic-reel pacing, and the size/readability of the estate. Combat and later chapters should not compensate for problems in this opening.
